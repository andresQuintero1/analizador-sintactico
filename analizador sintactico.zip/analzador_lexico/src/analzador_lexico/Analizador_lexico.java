/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analzador_lexico;

import java.util.ArrayList;
import java.util.Arrays;


/**
 *
 * @author FELIPE
 */
public class Analizador_lexico {

    /**
     * @param args the command line arguments
     */
    private final ArrayList<String> keyword=new ArrayList<>(Arrays.asList(
                                "false","true","none","and","as","assert","async",
                                "await","break","class","continue","def","del",
                                "elif","else","except","finally","for","from",
                                "global","import","if","in","is","lambda",
                                "nonlocal","pass","raise","return","try",
                                "with","while","yield","endw","endif","endfun"));
    private final ArrayList<String> constante=new ArrayList<>(Arrays.asList(
                                "None","notImplemented","Ellipsis","NaN","Inf",
                                "_debug_"));
    private final ArrayList<String> apertura=new ArrayList<>(Arrays.asList("(",
                                               "[","{"));
    private final ArrayList<String> cierre=new ArrayList<>(Arrays.asList(")","]"
                                                                ,"}"));
    private final ArrayList<String> simbolosEspeciales=new ArrayList<>(
                                    Arrays.asList("#","@",":",";","\""));
    private final ArrayList<String> aritmetico=new ArrayList<>(Arrays.asList("+",
                                                    "-","*","/","//","%","**"));
    private final ArrayList<String> relacional=new ArrayList<>(Arrays.asList("<",
                                                "<=",">",">=","!=","=="));
    private final ArrayList<String> logico=new ArrayList<>(Arrays.asList("or",
                                                "not","and"));
    private final ArrayList<String> asignacion=new ArrayList<>(Arrays.asList("=",
                                                "+=","-=","*=","/=","%=","**="));
    private final ArrayList<String> Bit_a_Bit=new ArrayList<>(Arrays.asList("&",
                                                "|","~","^","<<",">>"));
    
    
    public String[][] Tokenize(String frase){
        String[] chain=frase.split("\\s+");
        return this.identify(chain);
        
    }
    
    public String toStrings(String frase){
        String[] chain=frase.split("\\s+");
        String[][] tokens =this.identify(chain);
        String mensaje="";
        
        for (String[] token : tokens) {
            mensaje += token[0] + "  es un  " + token[1]+"\n";
        }
        
        return mensaje;
        
    }
    
    public String[][] identify(String[] chain){
        String [][] mensaje=new String[chain.length][2];
        
        for(int i=0;i<chain.length;i++){
            if(this.constante.contains(chain[i])){
                mensaje[i][0]=(chain[i]);
                mensaje[i][1]="constant";
            }
            
            chain[i]=chain[i].toLowerCase();
            if(this.keyword.contains(chain[i])){
                mensaje[i][0]=(chain[i]);
                mensaje[i][1]="keyword";
                
            }else if(this.apertura.contains(chain[i])){
                mensaje[i][0]=(chain[i]);
                mensaje[i][1]="op parenthesis";
                
            }else if(this.cierre.contains(chain[i])){
                mensaje[i][0]=(chain[i]);
                mensaje[i][1]="cl parenthesis";
                
            }else if(this.simbolosEspeciales.contains(chain[i])){
                mensaje[i][0]=(chain[i]);
                mensaje[i][1]="symbol";
                
            }else if(this.aritmetico.contains(chain[i])){
                mensaje[i][0]=(chain[i]);
                mensaje[i][1]="aritmetic";
                
            }else if(this.relacional.contains(chain[i])){
                mensaje[i][0]=(chain[i]);
                mensaje[i][1]="relacional";
                
            }else if(this.asignacion.contains(chain[i])){
                mensaje[i][0]=(chain[i]);
                mensaje[i][1]="assign";
                
            }else if(this.logico.contains(chain[i])){
                mensaje[i][0]=(chain[i]);
                mensaje[i][1]="Logic";
                
            }else if(this.Bit_a_Bit.contains(chain[i])){
                mensaje[i][0]=(chain[i]);
                mensaje[i][1]="Bits";
                
            }else if(chain[i].charAt(0)=="\"".charAt(0)&&
                    chain[i].charAt(chain[i].length()-1)=="\"".charAt(0) ){
                mensaje[i][0]=(chain[i]);
                mensaje[i][1]="String";   
                
            }else if(chain[i].matches("[+-]?\\d*(\\.\\d+)?")){
                mensaje[i][0]=(chain[i]);
                mensaje[i][1]="number";
            }else if(!this.simbolosEspeciales.contains(String.valueOf(
                    chain[i].charAt(0))) && !Character.isDigit(chain[i].charAt(0))){
                mensaje[i][0]=(chain[i]);
                mensaje[i][1]="identifier";
            }else{
                mensaje[i][0]=(chain[i]);
                mensaje[i][1]="Fuera del lenguaje";
            }
        
        }
        return mensaje;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Analizador_lexico an=new Analizador_lexico();
        Ingreso in=new Ingreso(an);
    }
    
}
