/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analzador_lexico;

/**
 *
 * @author FELIPE
 */
public class AnalizadorSintactico {
    private String[][] tokens;
    private String mensaje;
    private Analizador_lexico lex;
    private int max;
    
    public AnalizadorSintactico(){
        this.mensaje="";
        this.lex=new Analizador_lexico();
        max=0;
    }
    
    public void setTokens(String[][] t){
        this.tokens=t;
        max=this.tokens.length;
    }
    
    public boolean cicle(int x){            //while ( ident+ logico ident* ) : endw
        int x1=x+3;
        if(!"while".equals(tokens[x][0])){
            return false;
        }else{
            if(!tokens[x+1][0].equals("(")){
                return false;
            }else if(!tokens[x+2][1].equals("identifier")){
                return false;
            }else {
                if(tokens[x+3][1].equals("relacional")){
                    if(tokens[x+4][1].equals("identifier")|| tokens[x+4][1].equals("number")){
                        x1=x+5;
                    }else{
                return false;
                }                    
            }
            if(!tokens[x1][0].equals(")")){
                return false;
            }
            else if(!tokens[x1+1][0].equals(":")){
                return false;
            }else{
                for (int i=x1+2;i<tokens.length;i++){
                    if(tokens[i][0].equals("endw")){
                       this.mensaje(x,x1+1,i+1,"ciclo while");
                       return true;
                    }
                }
            }
        }
        }
        System.out.println("654");
        return false;
    }
    
    public boolean setVar(int x){
        int z=0;
        if(tokens[x][1].equals("identifier")){  //ident assign ident|number|string ( aritmetic ident|number|string)*
            if(tokens[x+1][1].equals("assign")){
                if(tokens[x+2][1].equals("String")||
                        tokens[x+2][1].equals("number")){
                    System.out.println("asignacion basica");
                    this.mensaje(x,x+3,x+3,"asignacion");
                    return true;
                }else if (tokens[x+2][1].equals("identifier")){
                    System.out.println("asignacion compuesta");
                    for (z=x+3;z<tokens.length;z++){
                        if(tokens[z][1].equals("aritmetic")){
                            System.out.println("hay opertadortes");
                            if (!tokens[z+1][1].equals("identifier")&&
                                    !tokens[z+1][1].equals("number")){
                                System.out.println("hay otro identificador");
                                this.mensaje(x,z,z,"asignacion");
                                return true;
                            }
                            z=z+1;
                            System.out.println("hay mas identificadores");
                        }else{
                            this.mensaje(x,z+1,z+1,"asignacion");
                            return true;
                        }
                       
                    }
                }
            }
            this.mensaje(x,z,z,"asignacion");
            return true;    
        }else{
            return false;
        }
    }
    
    public boolean function(int x){             //def indent+ ( indent* ) :  endfun
        int x2=0;
        if(x<this.tokens.length&&this.tokens[x][0].equals("def")){
            if(!this.tokens[x+1][1].equals("identifier")){
              return false;
            }else if(this.tokens[x+2][0].equals("(")){
              for(int i=x+3;i<tokens.length;i++){
                    if(this.tokens[i][1].equals("identifier")){
                        if(!this.tokens[i+1][0].equals(",")&&!this.tokens[i+1][0].equals(")")){
                            return false;
                        }else if(this.tokens[i+1][0].equals(")")){
                            x2=i+1;
                            break;
                        }
                    }else if(this.tokens[i][0].equals(")")){
                            x2=i;
                            break;
                        }
              }
              if(this.tokens[x2+1][0].equals(":")){
                  for(int j=x2+2;j<tokens.length;j++){
                      if(tokens[j][0].equals("endfun")){
                       this.mensaje(x,x2+2,j+1,"funcion");
                       return true;
                    }
                  }
              }
            }
        }

        return false;
    }
    
    public boolean ifClause(int x){                 //if ( ident relacional ident ): endif 
        if(this.tokens[x][0].equals("if")){
            if(!this.tokens[x+1][0].equals("(")){
                return false;
            }else if(!this.tokens[x+2][1].equals("identifier")&&!this.tokens[x+2][1].equals("number")){
                return false;
            }else if(!this.tokens[x+3][1].equals("relacional")){
                return false;                
            }else if(!this.tokens[x+4][1].equals("identifier")&&!this.tokens[x+4][1].equals("number")){
                return false;
            }else if(!this.tokens[x+5][0].equals(")")){
                return false;
            }else if(this.tokens[x+6][0].equals(":")){
                for(int i=x+7;i<tokens.length;i++){
                    if(this.tokens[i][0].equals("endif")){
                        this.mensaje(x, x+7, i+1,"condicion");
                        return true;
                    }
                }
            }
        }
        
        return false;
    }
    
    public void mensaje(int x, int x2, int x3,String tipo){
        
        if(tipo.equals("ciclo while")){
            for(int j=x;j<x2+1;j++){
                this.mensaje+=tokens[j][0]+" ";

                if(j==x2){
                    this.mensaje+="  #inicio de ciclo while\n";
                }
            }
            if(x3-1<this.max){
                this.max=x3-1;
            }
            if(x2+1<this.max){
                this.fraseAnalisis(x2+1);
            }
                this.mensaje+="\n"+tokens[x3-1][0] +"   #fin de ciclo while";

        }
        
        if(tipo.equals("asignacion")){
            System.out.println("llega");
            for(int j=x;j<x3;j++){
                if(j==x3-1){
                   this.mensaje+=tokens[j][0] +"   #asignacion de variable\n"; 
                }else{
                    this.mensaje+=tokens[j][0];
                }
                
            }
            if(x3<this.max){
                this.fraseAnalisis(x3);
            }
            
            
        }
        if(tipo.equals("funcion")){
            for(int j=x;j<x2;j++){
                this.mensaje+=tokens[j][0]+" ";

                if(j==x2-1){
                    this.mensaje+="  #inicio de declaracion de funcion \n";
                }
            }
            if(x3-1<this.max){
                this.max=x3-1;
            }
            if(x2<this.max){
                this.fraseAnalisis(x2);
            }
                this.mensaje+="\n"+tokens[x3-1][0] +"   #fin de declaracion de funcion\n";

        }
        if(tipo.equals("condicion")){
            for(int j=x;j<x2;j++){
                this.mensaje+=tokens[j][0]+" ";

                if(j==x2-1){
                    this.mensaje+="  #inicio de condicional if\n";
                }
            }
            if(x3-1<this.max){
                this.max=x3-1;
            }
            if(x2+1<this.max){
                this.fraseAnalisis(x2);
            }
                this.mensaje+="\n"+tokens[x3-1][0] +"   #fin de condicional\n";

        }
        
         if(tipo.equals("error")){
                this.mensaje+="a partir de aqui existen errores en el codigo revise sintaxis\n";
            for(int j=x;j<tokens.length;j++){
                this.mensaje+=tokens[j][0]+" ";
            }

        }
        
    }
    
    
    public void fraseAnalisis(int x){
        System.out.println("se prueba funcion con "+ x);
        if(!this.function(x)){
           if(!this.cicle(x)){
               System.out.println("se prueba ciclo");
               if(!this.ifClause(x)){
                   System.out.println("se prueba condicion");
                   if(!this.setVar(x)){
                       System.out.println("se prueba asignacion");
                       this.mensaje(x,0,0,"error");
                   }
               }
           } 
        }
        
    }
    
    public void setEstructura(String cadena){
        this.mensaje="";
        this.lex=new Analizador_lexico();
        this.setTokens(this.lex.Tokenize(cadena));
        System.out.println(this.lex.toStrings(cadena));
        this.fraseAnalisis(0);
    }
    
    public String getMensaje(){
        return this.mensaje;
    }
    
}
